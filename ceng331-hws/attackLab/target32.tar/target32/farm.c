/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_347(unsigned x)
{
    return x + 3287517512U;
}

unsigned addval_246(unsigned x)
{
    return x + 2445838664U;
}

unsigned addval_131(unsigned x)
{
    return x + 3750316075U;
}

unsigned addval_233(unsigned x)
{
    return x + 2428645704U;
}

void setval_282(unsigned *p)
{
    *p = 2428930376U;
}

void setval_318(unsigned *p)
{
    *p = 3284699456U;
}

unsigned getval_137()
{
    return 2425393497U;
}

void setval_222(unsigned *p)
{
    *p = 2447345992U;
}

void setval_319(unsigned *p)
{
    *p = 2465433928U;
}

void setval_391(unsigned *p)
{
    *p = 616796377U;
}

unsigned addval_365(unsigned x)
{
    return x + 3330885770U;
}

unsigned addval_466(unsigned x)
{
    return x + 3284240712U;
}

unsigned addval_157(unsigned x)
{
    return x + 3351392584U;
}

unsigned getval_419()
{
    return 2421794285U;
}

unsigned getval_297()
{
    return 3284699464U;
}

unsigned getval_468()
{
    return 3251013960U;
}

unsigned addval_487(unsigned x)
{
    return x + 2430568776U;
}

void setval_481(unsigned *p)
{
    *p = 3287515464U;
}

void setval_279(unsigned *p)
{
    *p = 4085860503U;
}

void setval_201(unsigned *p)
{
    *p = 3267463496U;
}

void setval_420(unsigned *p)
{
    *p = 3284283720U;
}

unsigned getval_336()
{
    return 3247000675U;
}

unsigned addval_116(unsigned x)
{
    return x + 3277430191U;
}

unsigned addval_114(unsigned x)
{
    return x + 3284240712U;
}

void setval_488(unsigned *p)
{
    *p = 3284568393U;
}

unsigned getval_350()
{
    return 3284699464U;
}

void setval_316(unsigned *p)
{
    *p = 2430568780U;
}

unsigned addval_340(unsigned x)
{
    return x + 3258042596U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
